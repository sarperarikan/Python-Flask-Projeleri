from flask import Flask
from pc_control_commands.pc_control import pc_control
from app_control_commands.app_control import app_control
from home_controller.home import home
import webbrowser as web 

app = Flask(__name__)
web.open('http://localhost:5000')
app.register_blueprint(pc_control)
app.register_blueprint(app_control)
app.register_blueprint(home)
app.secret_key = "fjşlsadfjaşlkdfjaşlk24327432984372983740183247"


if __name__=="__main__":
    app.run()