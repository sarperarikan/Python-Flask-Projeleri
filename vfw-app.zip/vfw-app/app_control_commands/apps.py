start_for_apps ={
'Not Defteri':'notepad.exe',
'ekran okuyucu':'narrator.exe',
'program Merkezi':'appwiz.cpl',
'kullanıcı hesapları':'netplwiz',
'hesap makinesi':'calc',
'denetim masası':'control',
'tarih saat':'timedate.cpl',
'Aygıt yöneticisi':'devmgmt.msc',
'disk temizleme':'cleanmgr',
'kişiselleştirme':'control desktop',
'güvenlik ve bakım':'wscui.cpl',
'wordpad':'write',
'dosya gezgini':'explorer',
'görev yöneticisi':'taskmgr',
'Sistem Bilgisi':'msinfo32',
'ses seviyesi':'sndvol',
'Bilgisayarı kapat':'shutdown /s',
'güç seçenekleri':'powercfg.cpl',
'ekran klavyesi':'osk',
'büyüteç':'magnify',

}

 