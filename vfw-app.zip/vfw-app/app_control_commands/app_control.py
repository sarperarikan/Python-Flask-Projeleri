from flask import Blueprint, render_template, request, jsonify, url_for, session
import app_control_commands.apps  as apps
import locale
import os

app_control = Blueprint('app_control',__name__)
locale.setlocale(locale.LC_ALL,'Turkish_Turkey.1254')

@app_control.route('/uygulama_calistir')
def uygulama():
    return render_template('app-control.html',title='Sesinizle Uygulama Çalıştırma',app=sorted(list(apps.start_for_apps.keys()),key=locale.strxfrm))

@app_control.route('/uygulama_calistir',methods=['POST'])
def uygulama_calistir():
    data = request.form
    transcription = data['transcription']
    response_data = {'transcription':transcription}
    os.system(apps.start_for_apps.get(response_data['transcription']))
    return jsonify(response_data)


