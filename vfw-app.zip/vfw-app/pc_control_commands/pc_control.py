from flask import Blueprint, render_template, request, jsonify, url_for, session, redirect
import keyboard as kb
import locale
import pc_control_commands.commands as cmd

pc_control = Blueprint('pc_control',__name__)
locale.setlocale(locale.LC_ALL,'Turkish_Turkey.1254')

@pc_control.route('/klavye')
def klavye():
    return render_template('pc-control.html',title='Klavye Kontrolü',commands=sorted(list(cmd.windows_commands.keys()),key=locale.strxfrm))

@pc_control.route('/command',methods=['POST'])
def command():
    data = request.form 
    transcription = data['transcription']
    response_data = {'transcription':transcription}
    print(response_data['transcription'])
    if cmd.windows_commands.get(response_data['transcription']):
        kb.press_and_release(cmd.windows_commands[response_data['transcription']])
    return jsonify(response_data)


