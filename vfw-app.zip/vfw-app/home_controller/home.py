from flask import Blueprint, render_template, jsonify, request, url_for, session, redirect
import sqlite3

home = Blueprint('home', __name__)

@home.route('/')
def index():
    return render_template('home-control.html', title='Ana-sayfa')


@home.route('/mods', methods=['POST'])
def mod():
    data = request.form
    transcription = data['transcription']
    response_data = {'transcription': transcription}
    return jsonify(response_data)


@home.route('/kaydet')
def kullanici_kaydet():
    with sqlite3.connect('settings.db') as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO user_data (KULLANICIADI, API, EMAIL) VALUES ('sarper', '1234324', 'sarperarikan@gmail.com')")
        conn.commit()
    return "Kayıt başarıyla alındı"


@home.route('/hakkinda')
def about():
    return render_template('about.html',title='Hakkında')