from flask import Flask
from wcag_generater.wcag import wcag
import os
from dotenv import load_dotenv
import webbrowser as web



web.open('http://localhost:5000/wcag')
app = Flask(__name__)

load_dotenv()
app.register_blueprint(wcag,url_prefix='/wcag')
  
if __name__ == "__main__":
    app.run(debug=True)