$(document).ready(function () {
    $('#generateBtn').click(function () {
        var code = $('#codeInput').val();
        $.ajax({
            type: 'POST',
            url: '/wcag/code',  // Flask uygulamanızdaki URL yapısına uygun
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            data: { code: code },
            success: function (response) {
                $('#result').text(response.improved_code);
            },
            error: function (error) {
                console.error(error);
                $('#result').text('Kod çalıştırılırken bir hata oluştu.');
            }
        });
    });
});

document.getElementById('copyBtn').addEventListener('click', function() {
    const resultText = document.getElementById('result').innerText;
    navigator.clipboard.writeText(resultText).then(function() {
        alert('Result copied to clipboard!');
    }, function(err) {
        alert('Failed to copy text: ', err);
    });
});
function htmlEntitiesDecode(str) {
    return str.replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
document.getElementById('exportBtn').addEventListener('click', function() {
    const resultContent = htmlEntitiesDecode(document.getElementById('result').innerHTML);
    fetch('/wcag/export', {
        method: 'POST',
        body: new URLSearchParams({ 'html_content': resultContent }),
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    .then(response => response.blob())
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'exported_result.html';
        document.body.appendChild(a);
        a.click();
        a.remove();
    });
});