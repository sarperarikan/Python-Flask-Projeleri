from flask import Blueprint, render_template, request, jsonify, Response
import openai
from dotenv import load_dotenv
import os
#from io import BytesIO

load_dotenv()
wcag = Blueprint('wcag', __name__)

# API anahtarınızı ortam değişkenlerinden almak daha güvenlidir.

openai.api_key = os.environ.get('api_key')

@wcag.route('/')
def index():
    # HTML sayfasını render et
    return render_template('wcag_generater.html', title='WCAG Code Generater')

@wcag.route('/code', methods=['POST'])
def generated_code():
    prompted_data = request.form.get('code')
    if prompted_data:
        max_token = 2000
        results = []
        prompt = prompted_data
        try:
            for i in range(0, len(prompt), max_token):
                chunk = prompt[i:i + max_token]
                response = openai.Completion.create(
                    engine="text-davinci-003",
                    prompt="Sen uzman bir web geliştiricisisin. Buna göre aşağıdaki kodu WCAG 2.1 AA standartlarına göre detaylıca düzenle ve iyileştir : " + chunk,
                    max_tokens=max_token
                )
                results.append(response.choices[0].text.strip())
            improved_code = ''.join(results)
            return jsonify(improved_code=improved_code)
        except openai.error.AuthenticationError as e:
            print("API geçersiz: ", e)
            return "API geçersiz. Lütfen geçerli bir API anahtarı sağlayın."
    else:
        return "Gönderilen veri boş."

@wcag.route('/export', methods=['POST'])
def export():
    # Kullanıcı tarafından gönderilen HTML içeriğini al
    html_content = request.form.get('html_content')
    if html_content:
        full_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exported Result</title>
</head>
<body>
    {html_content}
</body>
</html>"""
        return Response(full_html, mimetype='text/html')
    else:
        return jsonify({'error': 'No HTML content provided'}), 400
